"""Run from a hash-checked frozen package. No network, installation or chemistry inference."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()


def render(results):
    lines = ["# 固定版本引擎执行验收", "", "## 已知事实", "本轮仅验证冻结程序执行、证书回填和报告一致性，不是科学正确性验收。", "",
             "## 效果评估"]
    for item in results:
        lines.append(f"- {item['case_id']}：退出码{item['exit_code']}，证书与冻结预期完全一致={item['matches_expected']}。")
        if item.get("certificate"):
            for v in item["certificate"]["verdicts"]:
                lines.append(f"  - {v['reference_id']}：{v['verdict']}；阻断维度={v['blocking_dimension']}。")
    lines += ["", "## 推断边界", "数值比较与定位仍关闭；本次未检索文献、未确认产物、未核验科学口径。", "",
              "## 原始证书", "```json", json.dumps(results, ensure_ascii=False, indent=2), "```", ""]
    return "\n".join(lines)


def main():
    root = Path(__file__).resolve().parent
    manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    for name, expected in manifest["files"].items():
        if hashlib.sha256((root / name).read_bytes()).hexdigest() != expected:
            raise ValueError("Frozen file hash mismatch: " + name)
    destination = root / "execution"
    destination.mkdir(exist_ok=False)
    cases = json.loads((root / "cases.json").read_text(encoding="utf-8"))
    expected = json.loads((root / "expected.json").read_text(encoding="utf-8"))
    results, log = [], []
    for case in cases:
        name = case["id"]
        case_path = destination / (name + ".input.json")
        case_path.write_text(json.dumps(case["input"], ensure_ascii=False), encoding="utf-8")
        command = [sys.executable, "-I", str(root / "chemcritic_engine.py"), "--input", str(case_path)]
        result = subprocess.run(command, cwd=root, capture_output=True, encoding="utf-8", timeout=60)
        (destination / (name + ".stdout.json")).write_text(result.stdout, encoding="utf-8")
        (destination / (name + ".stderr.txt")).write_text(result.stderr, encoding="utf-8")
        certificate = json.loads(result.stdout) if result.returncode == 0 else None
        matches = result.returncode == expected[name]["exit_code"] and certificate == expected[name]["certificate"]
        if result.returncode != 0:
            matches = matches and "Conflicting outcome fields" in result.stderr
        results.append(dict(case_id=name, exit_code=result.returncode, certificate=certificate, matches_expected=matches))
        log.append(dict(case_id=name, command=command, exit_code=result.returncode))
    report = dict(scope="frozen_execution_and_certificate_fidelity_not_scientific_accuracy",
                  passed=all(r["matches_expected"] for r in results), cases=results,
                  program_sha256=manifest["files"]["chemcritic_engine.py"],
                  commands=log, network_used=False, numeric_comparison_enabled=False)
    (destination / "verification.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    text = render(results)
    (destination / "chemcritic_report.md").write_text(text, encoding="utf-8")
    files = {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in destination.iterdir() if p.is_file()}
    (destination / "SHA256SUMS.json").write_text(json.dumps(files, indent=2), encoding="utf-8")
    print(json.dumps({"passed":report["passed"], "cases":len(results), "output_dir":str(destination),
                      "report_sha256":files["chemcritic_report.md"], "program_sha256":report["program_sha256"]}))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError) as exc:
        print(json.dumps({"status":"failed", "error_category":type(exc).__name__, "message":str(exc)}))
        raise SystemExit(2)
